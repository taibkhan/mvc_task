from model import ModelClass
obj1=ModelClass()
class controller:

    def insert(self,username,address):
        #calling check method of model to check if a given username already exist
        flag=obj1.check(username)
        if(flag==0):
            #calling insert method of model to insert the record in database
            obj1.insert(username,address)
        else:
            print('username already exist')
        #calling show_db method of model to display current database
        obj1.show_db()

    def delete(self,username):
        flag=obj1.check(username)
        if(flag==1):
            #calling delete method of model to delete the employee with given username
            obj1.delete(username)
            print('user with username',username,'is deleted' )
        else:
            print('username doesnt exist')
        obj1.show_db()

    def update(self,username,updatedusername,updatedaddress):
        flag=obj1.check(username)
        if(flag==1):
            #calling update method of model to modify the details of a given username
            obj1.update(username,updatedusername,updatedaddress)
           
        else:
            print('username doesnt exist')
        obj1.show_db()
        