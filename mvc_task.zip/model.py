from pymongo import MongoClient
import pprint

try:
    #establishing connection with database
    conn= MongoClient()
    print('connected successfuly')
except:
    print('could not connect to mongodb')
    
db= conn['tes-database']
employees= db.employees
class ModelClass:
    #method to insert a record
    def insert(self, username, address):
        employee={
            'username': username,
            'address': address
        }
        employees.insert_one(employee)
        print('employee added successfuly')

    #method to delete a record
    def delete(self,username):
        employees.delete_one({"username":username}) 

    #method to check if a username exist in the database or not
    def check(self,username):
        results= employees.count_documents({
            'username': username
        })
        if(results>0):
            return 1
        else:
            return 0
    
    #method for displaying the contents of database
    def show_db(self):
        print('DATABASE:')
        employess= employees.find()
        for emp in employess:
            pprint.pprint(emp)
    #method to modify the existing details in the database
    def update(self,username,updatedusername,updatedaddress):
        employees.update_one( 
        {"username":username}, 
        { 
                "$set":{ 
                        "username":updatedusername,
                        "address":updatedaddress
                        }
                  
                } 
        )  