from flask import Flask
from flask import request
import json
from controller import controller
obj=controller()
app=Flask(__name__)
@app.route('/insert', methods=['POST'])
def insert():
    #getting data from curl command
    data=request.get_json()
    username=data['username']
    address=data['address']
    #calling insert method of controller
    obj.insert(username,address)
    return "success"

@app.route('/delete', methods=['POST'])
def delete():
    #getting data from curl command
    data=request.get_json()
    username=data['username']
    #calling delete method of controller
    obj.delete(username)
    return "success"

@app.route('/update',methods=['POST'])
def update():
    #getting data from curl command
    data=request.get_json()
    username=data['username']
    updatedusername=data['updatedusername']
    updatedaddress=data['updatedaddress']
    #calling update method of controller
    obj.update(username,updatedusername,updatedaddress)
    return "update success"
if(__name__=="__main__"):
    app.run()
